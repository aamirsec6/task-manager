const express = require('express');
const app = express();
const TaskData = require('../src/tasks.json')

let port = 3000;



//welcome
app.get('/', (req , res ) => {
    return res.status(200).send('Hello , Welcome to Task Manager') 
});

//retrieve all tasks
app.get('/tasks' , (req , res) => {
    return res.status(200).send(TaskData)
});

//retrieve the task by id
app.get('/tasks/:taskid' , (req , res) => {

    let taskidPassed = req.params.taskid;
    let taskmanager = TaskData.tasks  ;
    let result = taskmanager.filter(val => val.taskid == taskidPassed);
    return res.send(200).send(result);
});

//for server
app.listen(3000,(err)=>{
    if(err){
        console.log('SERVER DID NOT STARTED');
    }
    else{
        console.log('SERVER RUNNING ON PORT 3000');
        
    }
});